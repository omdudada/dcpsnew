<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Nashik Municipal Corporation ::
Nashik Municipal Corporation</title>



<script language="javascript" src="<?php echo base_url();?>assets/javascript/javascript.js"></script>
<!-- <link rel="shortcut icon" href="favicon.png" type="image/x-icon">
<link rel="icon" href="favicon.png" type="image/x-icon"> -->

<!-- ==== Google Font ==== -->
<link href='https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900%7CDroid+Serif:400,700' rel='stylesheet' type='text/css'>

<!--<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">-->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" 
integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/datatables.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/front/style.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/front/owl.carousel.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/front/swiper.min.css">
   
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/front/style1.css">
   
    <script src="<?php echo base_url();?>assets/js/jquery.js"></script>
    <script src="<?php echo base_url();?>assets/js/datatables.min.js"></script>
    <!--<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>-->
    
    
    
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
    
</head>
<body>




<!-- Preloader Start -->
<div id="preloader">
  <div class="preloader--spinner"></div>
</div>
<!-- Preloader End -->
<div class="indtheame"></div>
<!-- Header Area Start -->
<header id="header">
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <a class="navbar-brand" href="#"><img src="<?php echo base_url('assets/img/nmc_logo1234.png'); ?>"> </a>



  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
</nav>
</header>

    
    
    
    
    
    
    
    